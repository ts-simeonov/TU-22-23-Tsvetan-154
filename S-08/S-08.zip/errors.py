class InvalidCommand(Exception):
    def __init__(self, message='Invalid Menu choice, try again', *args):
        super().__init__(message, *args)

class InvalidDataFormat(Exception):
    def __init__(self, message='Invalid Data format', *args):
        super().__init__(message, *args)

class CharacterExists(Exception):
    def __init__(self, message='Character already exists', *args):
        super().__init__(message, *args)

class InvalidCharacterClass(Exception):
    pass

class CharacterNotFound(Exception):
    pass