from entities import Character
from errors import CharacterExists

class Game:
    def __init__(self):
        self.characters = []

    def find_char(self, name):
        for i in self.characters:
            if i.name == name:
                return i

    def add_char(self, name, sex, ch_class):
        found_char = self.find_char(name)

        if type(found_char) == Character:
            raise CharacterExists()
        char = Character(name, sex, ch_class)
        self.characters.append(char)