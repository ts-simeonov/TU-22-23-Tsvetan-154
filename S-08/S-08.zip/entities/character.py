class Character:
    def __init__(self, name, sex, ch_class, weapon, obj):
        self.name = name
        self.sex = sex
        self.sh_class = sh_class
        self.weapon = weapon
        self.object = obj