from obj import Object

class Weapon(Object):
    def __init__(self, name, attack):
        super().__init__(name)
        self.durability = 100
        self.attack = attack

    def print(self):
        return f'The weapon{self.name} with the attack {self.attack} has {self.durability} durability'