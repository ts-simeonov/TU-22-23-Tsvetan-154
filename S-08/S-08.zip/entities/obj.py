class Object:
    def __init__(self, name):
        self.name = name
        self.durability = 100

    def print(self):
        return f'The object {self.name} has {self.durability} durability'