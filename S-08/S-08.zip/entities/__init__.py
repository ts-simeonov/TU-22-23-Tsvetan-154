from character import Character
from obj import Object
from weapon import Weapon