from entities import Character
from errors import InvalidCommand, InvalidDataFormat

class Menu:
    def print_commands(self):
        print("1. Create a new character")
        print('2. Create a weapon for an existing character')
        print('3. Create an extra object for an existing character')
        print('4. List all characters')
        print('5. Delete a exisiting character')
        print('6. Exit')

    def command_create_character(self, name, sex, ch_class):
        pass

    def run(self):
        # infinite menu loop
        while True:  
            # print the menu
            self.print_commands()

            # ask the user to choose a command
            choice = input("Choose an item from the menu: \n> ")

            # catch errors
            try:
                # process the user's choice
                if choice == "1":                    
                    # ask the user to input the necessary command parameters
                    name = input("Enter the character name (alpha-numeric): ")
                    if not (name.isalnum() and len(name) < 4):
                        raise InvalidDataFormat

                    # ...

                    # char = self.command_create_character(....)
                    
                    # ...
                else:
                    raise InvalidCommand()
            except Exception as ex:
                print(f"Error: {str(ex)}")
            
            print()

if __name__ == '__main__':
    menu = Menu()
    menu.run()
